package nov13;


class Snake implements WHI{


	public void run() {
		System.out.println("cant run");
		
	}

	public void fly() {
		System.out.println("cant fly");
		
	}

	public void talk() {
		System.out.println("cant talk");
		
	}
	
	public void eye() {
		System.out.println("has small eyes");
	}
	
	public void leg() {
		System.out.println("has no legs");
	}
}

package nov13;


public class Snake implements WHI, Sound{

	
	public void sound() {
		System.out.println("����..?");
	}

	public void run() {
		System.out.println("cant run");
		
	}

	public void fly() {
		System.out.println("cant fly");
		
	}

	public void talk() {
		System.out.println("cant talk");
		
	}
	
	public void eye() {
		System.out.println("has small eyes");
	}
	
	public void leg() {
		System.out.println("has no legs");
	}
}

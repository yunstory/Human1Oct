package nov13;

public interface Sound {

	public void sound();
	
	
}

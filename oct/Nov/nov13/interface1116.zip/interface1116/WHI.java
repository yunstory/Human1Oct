package nov13;

public interface WHI {
	
	public void run();
	public void fly();
	public void talk();
	public void eye();
	public void leg();

}


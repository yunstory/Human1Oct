package nov13;

public class Yuns implements WHI, Sound{

	public void sound() {
		System.out.println("�ȳ���Th�Ŀ��");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("can run, LUV IT");
		
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("can not");
	}

	@Override
	public void talk() {
		// TODO Auto-generated method stub
		System.out.println("Im not good at Eng");
		
	}

	@Override
	public void eye() {
		// TODO Auto-generated method stub
		System.out.println("Little Big");
		
	}

	@Override
	public void leg() {
		// TODO Auto-generated method stub
		System.out.println("has 2 legs");
		
	}

	
	
}
